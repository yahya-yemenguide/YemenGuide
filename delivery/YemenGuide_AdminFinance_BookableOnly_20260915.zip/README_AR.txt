إصلاح المنشآت غير الحجزية في مالية الأدمن
=============================================
الملفات:
1) YemenGuide.Web/Services/Finance/AdminFinancialService.cs
2) YemenGuide.Web/Services/Finance/CommissionFinanceService.cs

- حسابات الضمان والشحن للمنشآت الحجزية فقط (BookingSystemId من 1 إلى 4).
- لا حذف ولا تعديل لقاعدة البيانات أو الحركات التاريخية.
- استبدل الملفين كاملين ثم Clean Solution ثم Rebuild Solution.
